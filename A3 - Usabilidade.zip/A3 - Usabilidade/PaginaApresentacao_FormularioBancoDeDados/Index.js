const express = require('express')
const mongoose = require('mongoose')
const app = express()
const Person = require('./Person') 

app.use(
  express.urlencoded({
    extended: true,
  }),
)

app.use(express.json())
//rotas api
app.post('/', async (req, res) => {

  //req.body
  const { nome, email, telefone, estado, duvida} = req.body
  //Vou mudar para os dados do formulario que vou colocar
  //nome, email, telefone, estado e o campo de duvida
  const person = new Person({
    nome,
    email,
    telefone,
    estado,
    duvida
  });

  await person.save();
  res.status(200).json({'mensagem': 'Dados enviados com sucesso'});
}) 

//rotas inicial / endpoint
app.get('/', (req, res) => {
})

mongoose.connect('mongodb+srv://Gustavo:aaNZKe3xdDh1vcpa@apicluster0.kprkk5f.mongodb.net/formulario?retryWrites=true&w=majority')
  .then(() => {
    console.log('Conectando ao MDB!')
    app.listen(3000)
  })
  .catch((err) => console.log(err))