const mongoose = require('mongoose')    
const Person = mongoose.model('Person',{
nome: String,
email: String,
telefone: Number,
estado: String,
duvida: String
})  

module.exports = Person
